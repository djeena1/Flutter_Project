import 'package:nanoue_boutik/services/product_provider.dart';
import 'package:provider/provider.dart';

import 'cart.dart';
import 'categorie_product.dart';
import 'package:flutter/material.dart';
import 'favorites.dart';
import '../services/utilities.dart' as util;

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int selectedIndex = 1;
  bool firstRun = true;

  List<Widget> pages = [
    FavoritesList(),
    const CategoriesProducts(category: null),
    CartList(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Color(0xFF1c1c1c),
        selectedItemColor: Colors.white,
        selectedLabelStyle: TextStyle(color: Colors.white),
         // fixedColor: Color(0xFF1c1c1c),
          currentIndex: selectedIndex,
          onTap: (value) {
            setState(() {
              selectedIndex = value;
            });
          },
          items: const [
            BottomNavigationBarItem(
              label: "Favorites", backgroundColor: Colors.white,
              icon: Icon(Icons.favorite,color: Colors.white,),
            ),
            BottomNavigationBarItem(label: "Home", backgroundColor: Colors.white,icon: Icon(Icons.home ,color: Colors.white,)),
            BottomNavigationBarItem(
                label: "My cart", backgroundColor: Colors.white, icon: Icon(Icons.shopping_cart ,color: Colors.white,))
          ]),
    );
  }
}
