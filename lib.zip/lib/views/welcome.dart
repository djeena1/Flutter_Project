import 'package:nanoue_boutik/services/api.dart';
import 'package:nanoue_boutik/views/loading.dart';
import 'package:nanoue_boutik/views/main_screen.dart';
import 'package:nanoue_boutik/views/payment.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';
import '../services/product_provider.dart';
import '../services/utilities.dart' as util;
import 'all_products.dart';
import 'login_page.dart';
import 'products_List.dart';

class MainPlaceHolder extends StatelessWidget {
  final bool wait;
  const MainPlaceHolder({super.key, required this.wait});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      color: Color(0xFF1c1c1c),
      title: 'Infinity',
      home: Scaffold(
        appBar: util.username != "admin"
            ? AppBar(
                title: Row(
                  children: [
                    Image.asset(
                      'images/img1.webp',
                      width: 200,
                      height: 40,
                    ),
                  ],
                ),
                actions: [
                  Container(
                    padding: const EdgeInsets.all(8.0),
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => const PaymentMethodPage()));
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white),
                      child: const Padding(
                        padding: EdgeInsets.all(2.0),
                        child: Text(
                          "Pay",
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ),
                  )
                ],
                backgroundColor: Color(0xFF1c1c1c),
              )
            : util.makeAppBar(null),
        drawer: Drawer(
          backgroundColor: Colors.white,
          child: ListView(
            children: <Widget>[
              Visibility(
                visible: util.username != "admin",
                child: UserAccountsDrawerHeader(
                  accountName: Text(
                    util.username,
                  ),
                  accountEmail: null,
                  currentAccountPicture: GestureDetector(
                    child: const CircleAvatar(
                      foregroundColor: Color(0xFF1c1c1c),
                      backgroundColor: Colors.white,
                      child: Icon(Icons.person),
                    ),
                  ),
                  decoration: const BoxDecoration(color: Color(0xFF1c1c1c)),
                ),
              ),
              Visibility(
                visible: util.username == "admin",
                child: InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    await util.GlobalVariables.getFavoriteProducts();
                    await util.GlobalVariables.getProductsInCart();
                    ProductProvider productProvider =
                        // ignore: use_build_context_synchronously
                        context.read<ProductProvider>();
                    // Modifying properties
                    productProvider.favoriteProducts =
                        util.GlobalVariables.favoriteProducts;
                    productProvider.inCartProducts =
                        util.GlobalVariables.productsInCart;

                    productProvider.notifyListeners();
                    

                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => LoginPage()));
                  },
                  child: const ListTile(
                    title: Text('Log In'),
                    leading: Icon(
                      Icons.login,
                      color: Color(0xFF1c1c1c),
                    ),
                  ),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) {
                      return Scaffold(
                        appBar: util.makeAppBar(IconButton(
                          icon: const Icon(Icons.arrow_back),
                          onPressed: () => Navigator.pop(context),
                        )),
                        body: Padding(
                          padding: const EdgeInsets.all(12),
                          child: AllProducts(
                            topProductsOnly: false,
                          ),
                        ),
                      );
                    }),
                  );
                },
                child: const ListTile(
                  title: Text('All products'),
                  leading: Icon(
                    Icons.list,
                    color: Color(0xFF1c1c1c),
                  ),
                ),
              ),
              InkWell(
                onTap: () {},
                child: const ListTile(
                  title: Text('Explore'),
                  leading: Icon(
                    Icons.search,
                    color: Color(0xFF1c1c1c),
                  ),
                ),
              ),
              InkWell(
                onTap: () {},
                child: const ListTile(
                  title: Text('Contact'),
                  leading: Icon(
                    Icons.contact_page,
                    color: Color(0xFF1c1c1c),
                  ),
                ),
              ),
              const Divider(),
              InkWell(
                onTap: () {},
                child: const ListTile(
                  title: Text('Invite friends'),
                  leading: Icon(
                    Icons.group_add,
                    color: util.navyBlue,
                  ),
                ),
              ),
              InkWell(
                onTap: () {},
                child: const ListTile(
                  title: Text('Settings'),
                  leading: Icon(
                    Icons.settings,
                    color: util.navyBlue,
                  ),
                ),
              ),
              InkWell(
                onTap: () {},
                child: const ListTile(
                  title: Text('About'),
                  leading: Icon(
                    Icons.help,
                    color: Color(0xFF1c1c1c),
                  ),
                ),
              ),
              Visibility(
                visible: util.username != "admin",
                child: InkWell(
                  onTap: () async {
                    util.reloadRequired = true;
                    await util.Storage.logOutUser();
                    await util.GlobalVariables.getFavoriteProducts();
                    ProductProvider productProvider =
                        // ignore: use_build_context_synchronously
                        context.read<ProductProvider>();
                    // Modifying properties
                    productProvider.favoriteProducts =
                        util.GlobalVariables.favoriteProducts;
                    productProvider.inCartProducts =
                        util.GlobalVariables.productsInCart;
                    // Notify listeners to trigger a rebuild
                    // ignore: invalid_use_of_visible_for_testing_member
                    productProvider.notifyListeners();
                    Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(
                            builder: (BuildContext context) => const Welcome()),
                        (Route<dynamic> route) => false);
                  },
                  child: const ListTile(
                    title: Text('Log Out'),
                    leading: Icon(
                      Icons.exit_to_app,
                      color: Color(0xFF1c1c1c),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        body: Visibility(
          visible: wait,
          replacement: const MainScreen(),
          child: const LoadingScreen(),
        ),
      ),
    );
    ;
  }
}

class Welcome extends StatefulWidget {
  const Welcome({super.key});

  @override
  State<Welcome> createState() => _WelcomeState();
}

class _WelcomeState extends State<Welcome> {
  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    bool isMounted = true; // Flag to track the mounted status

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: FutureBuilder<List<Product>?>(
          future: APIService.getProducts(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              // Data is still loading, display a circular progress indicator
              return const MainPlaceHolder(wait: true);
            } else if (snapshot.hasError) {
              // Error occurred while fetching data
              return Text('Error: ${snapshot.error}');
            } else {
              // Data loaded successfully, use your custom widget
              List<Product>? products = snapshot.data;
              ProductProvider productProvider = context.read<ProductProvider>();

              WidgetsBinding.instance.addPostFrameCallback((_) async {
                if (isMounted) {
                  // Modifying properties
                  productProvider.products = products ?? <Product>[];
                  await util.GlobalVariables.getFavoriteProducts();
                  await util.GlobalVariables.getProductsInCart();
                  productProvider.favoriteProducts =
                      util.GlobalVariables.favoriteProducts;
                  productProvider.inCartProducts =
                      util.GlobalVariables.productsInCart;

                  // Notify listeners to trigger a rebuild
                  // ignore: invalid_use_of_visible_for_testing_member
                  productProvider.notifyListeners();
                }
              });

              if (products != null && products.isNotEmpty) {
                // Return your custom widget using the loaded data
                return const MainPlaceHolder(wait: false);
              } else {
                // No data available
                return const Text('No data available');
              }
            }
          },
        ),
      ),
    );
  }
}
