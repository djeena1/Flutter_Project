import 'package:nanoue_boutik/models/categories.dart';
import 'package:nanoue_boutik/views/all_products.dart';
import 'package:nanoue_boutik/views/categories_carousel.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/product.dart';
import '../services/product_provider.dart';
import '../services/utilities.dart';

@immutable
class CategoriesProducts extends StatefulWidget {
  final Category? category;
  const CategoriesProducts({super.key, required this.category});

  @override
  State<CategoriesProducts> createState() =>
      _CategoriesProductsState(category: category);
}

class _CategoriesProductsState extends State<CategoriesProducts> {
  Category? category;
  _CategoriesProductsState({required this.category});
  String _categoryText = 'Top Categories';
  String _productsText = 'Top Products';
  AppBar? appBar;
  Widget categoryCarousel =
      CategoriesCarousel(categories: GlobalVariables.getCategories());
  double _heightProducts = 280;
  List<Product> productsDisplayed = [];

  @override
  Widget build(BuildContext context) {
    List<Product> products = context.watch<ProductProvider>().products;
    if (category != null) {
      _categoryText = category?.name.toUpperCase() ?? "";
      _productsText = 'Available products';
      _heightProducts = 360;
      categoryCarousel = CarouselCard(
              category: category ??
                  Category(name: category?.name ?? "", imageLink: ""))
          .container;
      appBar = makeAppBar(IconButton(
        icon: const Icon(Icons.arrow_back),
        onPressed: () => Navigator.pop(context),
      ));
    }

    return Scaffold(
      appBar: appBar, 
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 12.0, bottom: 12.0),
            child: Text(
              _categoryText,
              style: const TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          SizedBox(height: 200, child: categoryCarousel),
          Padding(
            padding: const EdgeInsets.only(bottom: 12.0),
            child: Text(
              _productsText,
              style: const TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          SizedBox(
            height: _heightProducts,
            child: AllProducts(
              categoryName: category?.name,
              topProductsOnly: category?.name == null ? true : false,
            ),
          ),
        ],
      ),
    );
  }
}