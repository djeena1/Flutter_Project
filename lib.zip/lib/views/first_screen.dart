import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nanoue_boutik/views/welcome.dart';

class First_screen extends StatelessWidget {
  const First_screen({Key? key});

  @override
  Widget build(BuildContext context) {
    Timer(Duration(seconds: 4), () {
      Get.to(Welcome());
    });
    return Scaffold(
      backgroundColor: Color(0xFF1c1c1c),
      body: Center(
        child: Image.asset(
          'images/img2.jpg',
          width: 200,
          height: 200, 
        ),
      ),
    );
  }
}
