import 'package:flutter/material.dart';
import 'all_products.dart';

class ProductsList extends StatelessWidget {
  const ProductsList({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              // controller: _searchController,
              // focusNode: _searchFocusNode,
              onTap: () {
                //  _searchFocusNode.unfocus();
              },
              decoration: InputDecoration(
                hintText: 'Search products...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.grey[200],
                contentPadding: EdgeInsets.all(8),
              ),
              onChanged: (value) {
                //     _filterProducts(value);
              },
            ),
          ),
          AllProducts(topProductsOnly: false),
        ],
      ),
    );
  }
}
