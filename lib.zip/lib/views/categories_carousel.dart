import 'package:nanoue_boutik/views/categorie_product.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import '../models/categories.dart';

class CarouselCard extends StatelessWidget {
  final Category category;
  Widget container = Container();
  CarouselCard({super.key, required this.category}) {
    container = Container(
      margin: const EdgeInsets.symmetric(
        horizontal: 1.0,
      ),
      width: 155.0,
      height: 10.0,
      color: Colors.white,
      child: ClipRRect(
          borderRadius: const BorderRadius.all(Radius.circular(5.0)),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Image.network(
                category.imageLink,
                fit: BoxFit.fill,
                width: 150.0,
                height: 100.0,
              ),
              SizedBox(
                height: 8,
              ),
              Text(
                category.name,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          )),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => CategoriesProducts(category: category),
          ),
        ),
      },
      child: container,
    );
  }
}

@immutable
class CategoriesCarousel extends StatelessWidget {
  final List<Category> categories;
  const CategoriesCarousel({super.key, required this.categories});

  @override
  Widget build(BuildContext context) {
    return CarouselSlider(
      options: CarouselOptions(
        //aspectRatio: 2.0,
        enlargeCenterPage: true,
        enableInfiniteScroll: false,
        initialPage: 2,
        autoPlay: false,
      ),
      items: categories
          .map((category) => CarouselCard(category: category))
          .toList(),
    );
  }
}
