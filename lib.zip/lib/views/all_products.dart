import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:nanoue_boutik/services/utilities.dart' as util;
import 'package:nanoue_boutik/views/ask_to_login.dart';
import 'package:nanoue_boutik/views/product_detail.dart';
import '../models/product.dart';
import '../services/product_provider.dart';

@immutable
class AllProducts extends StatelessWidget {
  final String? categoryName;
  final bool topProductsOnly;

  const AllProducts({Key? key, this.categoryName, required this.topProductsOnly})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<Product> products = context.watch<ProductProvider>().products;
    List<Product> favoriteProducts = context.watch<ProductProvider>().favoriteProducts;
    List<Product> inCartProducts = context.watch<ProductProvider>().inCartProducts;

    if (categoryName != null) {
      products = products.where((element) => element.category == categoryName).toList();
    } else if (topProductsOnly == true) {
      List<Product> sortedProducts = util.sortProducts(products);
      int endIndex = sortedProducts.length > 6 ? 6 : sortedProducts.length;
      products = sortedProducts.sublist(0, endIndex);
    }

    return GridView.builder(
      shrinkWrap: true,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12.0,
        mainAxisSpacing: 8.0,
        mainAxisExtent: 320.0,
      ),
      itemCount: products.length,
      itemBuilder: (context, index) {
        return GestureDetector(
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => ProductDetailPage(product: products[index]),
              ),
            );
          },
          child: Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16.0),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(16.0),
                    topRight: Radius.circular(16.0),
                  ),
                  child: Image.network(
                    products[index].image,
                    height: 150,
                    width: double.infinity,
                    fit: BoxFit.fill,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        products[index].title,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4.0),
                      Text(
                        'Price: ${products[index].price} USD',
                        style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green, fontSize: 14),
                      ),
                      const SizedBox(height: 4.0),
                      Text(
                        'Rating: ${products[index].rate}/5.0',
                        style: const TextStyle(fontSize: 12),
                      ),
                    ],
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    IconButton(
                      onPressed: () {
                        if (util.username == "admin") {
                          Navigator.of(context).push(MaterialPageRoute(builder: (context) => const LoginPrompt()));
                        } else {
                          Product currentProduct = products[index];
                          if (!favoriteProducts.contains(currentProduct)) {
                            context.read<ProductProvider>().addToFavorites(currentProduct);
                          } else {
                            context.read<ProductProvider>().removeFromFavorites(currentProduct);
                          }
                        }
                      },
                      color: favoriteProducts.contains(products[index]) ? Colors.red : Colors.black,
                      icon: const Icon(Icons.favorite, size: 24),
                    ),
                    IconButton(
                      onPressed: () {
                        if (util.username == "admin") {
                          Navigator.of(context).push(MaterialPageRoute(builder: (context) => const LoginPrompt()));
                        } else {
                          Product currentProduct = products[index];
                          if (!inCartProducts.contains(currentProduct)) {
                            context.read<ProductProvider>().addToCart(currentProduct);
                          } else {
                            context.read<ProductProvider>().removeFromCart(currentProduct);
                          }
                        }
                      },
                      color: inCartProducts.contains(products[index]) ? Colors.red : Colors.black,
                      icon: const Icon(Icons.shopping_cart, size: 24),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
